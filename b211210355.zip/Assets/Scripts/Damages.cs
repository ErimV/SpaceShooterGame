public enum Damages
{
    BulletHit = 1,
    EnemyCollide = 2,
    Enemy2Collide = 6,
    AsteroidCollide = 5,
    SmallAsteroidCollide = 2
}