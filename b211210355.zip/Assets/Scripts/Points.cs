public enum Points
{
    EnemyDestroyed = 10,
    Enemy2Destroyed = 60,
    AsteroidDestroyed = 40,
    SmallAsteroidDestroyed = 10
}